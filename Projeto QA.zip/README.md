Turma: Sistemas para internet P5A - Noite

Grupo: Lucas Soares Kirchesch - Matheus Alcantara - Jose Gomes - Luciano Lira - Alexander Dore - Rafhael Matias

Desenvolvimento: Exploração de falhas e verificação de funcionamento do Site [Gov.br](https://www.gov.br/pt-br) através de 5 cenários

Cenário 1: Verificação de Redirecionamento para Página de Login
Cenário 2: Encontrar ferramenta de busca e digitar algo para teste
Cenário 3: Busca do atributo href para redirecionar a outra parte da página(CPF)
Cenário 4: Alterar linguagem para Ingles
Cenário 5: Alterar linguagem para Espanhol